BIN BLASTERS WEBSITE SETUP

1. Open index.html
2. Replace THIS line in the form:

https://formspree.io/f/YOUR_FORM_ID

with your real Formspree form link.

3. Upload to GitHub Pages or any hosting (Netlify recommended).

HOW FORM WORKS:
- When someone submits the form, Formspree emails you automatically.
- You don't need Google Forms anymore.

NEXT STEP (optional upgrade):
- I can add logo, animations, or online payment system.
